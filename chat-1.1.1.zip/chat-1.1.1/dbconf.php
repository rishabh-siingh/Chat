<?php
/**
 * Created by PhpStorm.
 * User: lukas
 * Date: 15.01.17
 * Time: 13:10
 */
define ( 'MYSQL_KENNWORT',  'Zensiert' );
define ( 'MYSQL_HOST',      'localhost' );
define ( 'MYSQL_BENUTZER',  'chat' );
define ( 'MYSQL_DATENBANK', 'chat' );
define ( 'MYSQL_PORT', '3306' );
?>
